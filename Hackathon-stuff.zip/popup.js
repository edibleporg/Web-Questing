document.getElementById('carbon').textContent = selectedCompany.carbon;

// const setDOMInfo = info => {  
//     let selectedCompany = companyData.filter(company => (
//       company.companyName === info.manufacturer
//     ))
//     selectedCompany = selectedCompany[0];
//     let score = 100 - (selectedCompany.mainScore * 2);
