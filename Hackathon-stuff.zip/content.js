document.getElementById('energy').textContent = 100;
// document.getElementById('energy').textContent = document.getElementById('energy').textContent-1;